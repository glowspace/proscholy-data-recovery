-- Adminer 5.4.1 MySQL 5.7.44 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` int(11) DEFAULT '0',
  `visits` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authors_type_index` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `author_external`;
CREATE TABLE `author_external` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(10) unsigned NOT NULL,
  `external_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `author_external_author_id_foreign` (`author_id`),
  KEY `author_external_external_id_foreign` (`external_id`),
  CONSTRAINT `author_external_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `author_external_external_id_foreign` FOREIGN KEY (`external_id`) REFERENCES `externals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `author_file`;
CREATE TABLE `author_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `author_file_author_id_foreign` (`author_id`),
  KEY `author_file_file_id_foreign` (`file_id`),
  CONSTRAINT `author_file_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `author_file_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `author_membership`;
CREATE TABLE `author_membership` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(10) unsigned NOT NULL,
  `is_member_of` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `author_membership_author_id_foreign` (`author_id`),
  KEY `author_membership_is_member_of_foreign` (`is_member_of`),
  CONSTRAINT `author_membership_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `author_membership_is_member_of_foreign` FOREIGN KEY (`is_member_of`) REFERENCES `authors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `author_song_lyric`;
CREATE TABLE `author_song_lyric` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(10) unsigned NOT NULL,
  `song_lyric_id` int(10) unsigned NOT NULL,
  `authorship_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `author_song_lyric_author_id_foreign` (`author_id`),
  KEY `author_song_lyric_song_lyric_id_foreign` (`song_lyric_id`),
  CONSTRAINT `author_song_lyric_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `author_song_lyric_song_lyric_id_foreign` FOREIGN KEY (`song_lyric_id`) REFERENCES `song_lyrics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `author_user`;
CREATE TABLE `author_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `author_user_user_id_foreign` (`user_id`),
  KEY `author_user_author_id_foreign` (`author_id`),
  CONSTRAINT `author_user_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `author_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `data_rows`;
CREATE TABLE `data_rows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_type_id` int(10) unsigned NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `browse` tinyint(1) NOT NULL DEFAULT '1',
  `read` tinyint(1) NOT NULL DEFAULT '1',
  `edit` tinyint(1) NOT NULL DEFAULT '1',
  `add` tinyint(1) NOT NULL DEFAULT '1',
  `delete` tinyint(1) NOT NULL DEFAULT '1',
  `details` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `data_rows_data_type_id_foreign` (`data_type_id`),
  CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `data_types`;
CREATE TABLE `data_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT '0',
  `server_side` tinyint(4) NOT NULL DEFAULT '0',
  `details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `data_types_name_unique` (`name`),
  UNIQUE KEY `data_types_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `elastic_migrations`;
CREATE TABLE `elastic_migrations` (
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `externals`;
CREATE TABLE `externals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `song_lyric_id` int(10) unsigned DEFAULT NULL,
  `author_id__obsolete` int(10) unsigned DEFAULT NULL,
  `visits` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `url` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `has_anonymous_author` tinyint(1) NOT NULL DEFAULT '0',
  `catalog_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_uploaded` tinyint(1) NOT NULL DEFAULT '0',
  `caption` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `media_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_type` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `videos_song_lyric_id_foreign` (`song_lyric_id`),
  KEY `videos_author_id_foreign` (`author_id__obsolete`),
  KEY `externals_media_type_index` (`media_type`),
  KEY `externals_content_type_index` (`content_type`),
  KEY `externals_is_uploaded_index` (`is_uploaded`),
  CONSTRAINT `videos_author_id_foreign` FOREIGN KEY (`author_id__obsolete`) REFERENCES `authors` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `videos_song_lyric_id_foreign` FOREIGN KEY (`song_lyric_id`) REFERENCES `song_lyrics` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  `song_lyric_id` int(10) unsigned DEFAULT NULL,
  `author_id__obsolete` int(10) unsigned DEFAULT NULL,
  `licence_type` int(11) DEFAULT NULL,
  `licence_content` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_anonymous_author` tinyint(1) NOT NULL DEFAULT '0',
  `downloads` int(10) unsigned NOT NULL DEFAULT '0',
  `catalog_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `files_song_lyric_id_foreign` (`song_lyric_id`),
  KEY `files_author_id_foreign` (`author_id__obsolete`),
  CONSTRAINT `files_author_id_foreign` FOREIGN KEY (`author_id__obsolete`) REFERENCES `authors` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `files_song_lyric_id_foreign` FOREIGN KEY (`song_lyric_id`) REFERENCES `song_lyrics` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `lilypond_parts_sheet_music`;
CREATE TABLE `lilypond_parts_sheet_music` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `song_lyric_id` int(10) unsigned NOT NULL,
  `lilypond_parts` json NOT NULL,
  `global_src` text COLLATE utf8mb4_unicode_ci,
  `score_config` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_empty` tinyint(1) NOT NULL DEFAULT '0',
  `sequence_string` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `liturgical_references`;
CREATE TABLE `liturgical_references` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `song_lyric_id` int(10) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cycle` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `liturgical_year_readings`;
CREATE TABLE `liturgical_year_readings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `reference_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `references_others` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `liturgical_year_readings_date_index` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `menu_items`;
CREATE TABLE `menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `menu_items_menu_id_foreign` (`menu_id`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2015_08_16_103748_create_users_table',	1),
(2,	'2016_01_01_000000_add_voyager_user_fields',	1),
(3,	'2016_01_01_000000_create_data_types_table',	1),
(4,	'2016_05_19_173453_create_menu_table',	1),
(5,	'2016_10_21_190000_create_roles_table',	1),
(6,	'2016_10_21_190000_create_settings_table',	1),
(7,	'2016_11_30_135954_create_permission_table',	1),
(8,	'2016_11_30_141208_create_permission_role_table',	1),
(9,	'2016_12_26_201236_data_types__add__server_side',	1),
(10,	'2017_01_13_000000_add_route_to_menu_items_table',	1),
(11,	'2017_01_14_005015_create_translations_table',	1),
(12,	'2017_01_15_000000_make_table_name_nullable_in_permissions_table',	1),
(13,	'2017_03_06_000000_add_controller_to_data_types_table',	1),
(14,	'2017_04_21_000000_add_order_to_data_rows_table',	1),
(15,	'2017_07_05_210000_add_policyname_to_data_types_table',	1),
(16,	'2017_08_05_000000_add_group_to_settings_table',	1),
(17,	'2017_11_26_013050_add_user_role_relationship',	1),
(18,	'2017_11_26_015000_create_user_roles_table',	1),
(19,	'2018_03_11_000000_add_user_settings',	1),
(20,	'2018_03_14_000000_add_details_to_data_types_table',	1),
(21,	'2018_03_16_000000_make_settings_value_nullable',	1),
(22,	'2018_08_23_134630_create_songs_table',	1),
(23,	'2018_08_23_134631_create_song_lyrics_table',	1),
(24,	'2018_08_23_134632_create_authors_table',	1),
(25,	'2018_08_23_134633_create_author_song_lyric_table',	1),
(26,	'2018_08_23_134634_create_author_membership_table',	1),
(27,	'2018_08_23_134635_create_songbooks_table',	1),
(28,	'2018_08_23_134636_create_songbook_records_table',	1),
(29,	'2018_08_23_134637_create_files_table',	1),
(30,	'2018_08_23_134638_create_videos_table',	1),
(31,	'2019_02_16_140341_rename_videos_table_to_externals',	1),
(32,	'2019_02_16_151841_add_default_to_lang',	1),
(33,	'2019_02_16_175635_add_default_to_author_visits',	1),
(34,	'2019_02_16_212608_update_authors_table',	1),
(35,	'2019_02_16_214555_add_default_to_external_visits',	1),
(36,	'2019_02_17_090458_add_type_to_files_table',	1),
(37,	'2019_02_17_090810_add_type_default_in_externals_table',	1),
(38,	'2019_02_21_185905_create_permission_tables',	2),
(39,	'2019_02_22_194835_make_fields_nullable_in_users_table',	3),
(40,	'2019_02_22_225016_add_path_to_files_table',	3),
(41,	'2019_02_23_094927_add_name_to_files_table',	3),
(42,	'2019_02_23_110104_add_updating_at_to_song_lyrics_table',	3),
(43,	'2019_02_23_143629_add_has_anonymous_author_to_song_lyrics_table',	4),
(44,	'2019_02_23_163036_add_is_featured_to_externals_table',	5),
(45,	'2019_02_23_174746_add_has_anonymous_author_to_externals_and_files_table',	6),
(46,	'2019_02_27_121621_add_downloads_to_files_table',	7),
(47,	'2019_02_27_170730_set_default_is_original_to_true_in_song_lyrics_table',	7),
(48,	'2019_03_14_155843_add_formatted_lyrics_to_song_lyrics_table',	8),
(49,	'2019_03_14_161425_rename_is_opensong_to_has_chords_in_song_lyrics_table',	8),
(50,	'2019_03_14_164907_force_recaching_of_song_lyrics',	8),
(51,	'2019_03_16_143807_create_tags_table',	9),
(52,	'2019_03_16_144132_create_song_lyric_tag_table',	9),
(53,	'2019_03_18_175210_create_associated_author_user_table',	9),
(54,	'2019_03_21_142443_add_columns_concerning_authors_to_song_lyrics_table',	9),
(55,	'2019_03_21_150136_add_user_creator_id_to_song_lyrics_table',	9),
(56,	'2019_05_07_152106_add_api_token_to_users_table',	10),
(57,	'2019_05_09_073236_add_author_external_table',	11),
(58,	'2019_05_09_073245_add_author_file_table',	11),
(59,	'2019_05_09_073723_associate_authors_to_externals_and_files',	11),
(60,	'2019_05_09_084718_delete_duplicate_authors',	11),
(61,	'2019_05_12_075804_merge_original_and_authorized_to_type_in_song_lyrics_table',	12),
(62,	'2019_05_21_062848_make_songs_soft_deletable',	12),
(63,	'2019_05_24_081405_make_placeholder_nullable_in_songbook_records_table',	13),
(64,	'2019_05_26_184500_add_shortcut_to_songbooks_table',	13),
(65,	'2019_05_29_082040_remove_formatted_lyrics_from_song_lyrics_table',	14),
(66,	'2019_05_29_103206_add_only_regenschori_to_song_lyrics_table',	14),
(67,	'2013_04_09_062329_create_revisions_table',	15),
(68,	'2019_06_02_193400_add_songs_count_to_songbooks_table',	16),
(69,	'2019_06_19_110710_add_updating_at_to_songbooks_table',	17),
(70,	'2019_06_20_161628_add_capo_to_song_lyrics_table',	17),
(71,	'2019_06_21_110507_add_is_private_to_songbooks_table',	17),
(72,	'2019_06_21_120621_refactor_visits',	17),
(73,	'2019_08_04_102656_add_color_to_songbooks_table',	17),
(74,	'2019_11_03_143741_add_liturgy_approval_status_to_song_lyrics_table',	18),
(75,	'2019_12_08_115717_create_public_users_table',	19),
(76,	'2019_12_08_143408_create_playlists_table_and_pivot_table',	19),
(77,	'2019_12_14_070649_add_last_jwt_token_to_public_users_table',	19),
(78,	'2020_04_24_214143_migrate_song_lyric_tags_to_universal_tags',	19),
(79,	'2020_04_25_104757_add_arrangement_relation_to_song_lyrics_table',	19),
(80,	'2020_04_25_120138_make_type_nullable_in_song_lyrics_table',	19),
(81,	'2020_04_25_124754_make_song_id_nullable_in_song_lyrics_table',	19),
(82,	'2020_04_26_094810_migrate_parent_tags_to_tags_types',	19),
(83,	'2020_05_10_063131_add_missa_type_to_song_lyrics_table',	19),
(84,	'2020_05_10_065155_add_string_attributes_to_files_and_externals',	19),
(85,	'2020_06_13_163229_add_lilypond_to_song_lyrics_table',	19),
(86,	'2020_06_14_121647_edit_author_song_lyric_pivot_type',	19),
(87,	'2020_06_23_131029_add_is_admin_to_public_users_table',	19),
(88,	'2020_06_23_132327_change_is_admin_to_admin_user_id_in_public_users_table',	19),
(89,	'2020_06_30_162439_create_password_resets_table_lol_year_later',	19),
(90,	'2020_07_02_204222_add_song_number_to_song_lyrics_table',	19),
(91,	'2020_08_18_071710_remove_missa_type_from_song_lyrics_table',	20),
(92,	'2020_08_19_125118_create_visits_table',	20),
(93,	'2020_08_20_125713_add_color_text_to_songbooks_table',	20),
(94,	'2020_08_23_144037_create_news_items_table',	20),
(96,	'2020_09_24_220556_add_bible_refs_src_and_bible_refs_osis_to_song_lyrics_table',	22),
(97,	'2020_10_19_173304_add_stats_json_to_users_table',	23),
(98,	'2020_09_23_083808_add_is_uploaded_and_caption_to_externals_table',	24),
(99,	'2020_09_23_095610_add_media_type_and_content_type_to_externals_table',	24),
(100,	'2020_09_23_195146_migrate_files_to_externals',	24),
(101,	'2020_09_23_200939_add_media_and_content_types_to_externals',	24),
(102,	'2020_09_24_165750_remove_type_from_externals_table',	24),
(103,	'2020_10_25_202513_unify_jpeg_file_type_in_externals_table',	24),
(104,	'2020_09_22_183434_rename_public_files',	25),
(105,	'2020_10_29_192739_create_liturgical_references_table',	26),
(106,	'2020_11_01_160037_create_liturgical_year_readings_table',	27),
(107,	'2020_11_10_152034_add_songbook_img_url_to_songbooks_table',	27),
(108,	'2020_11_13_174230_add_secondary_names_to_song_lyrics_table',	27),
(109,	'2020_11_14_002926_add_admin_note_to_song_lyrics_table',	27),
(110,	'2020_11_16_181534_add_hide_in_liturgy_to_tags_table',	28),
(111,	'2020_11_18_003432_add_license_type_to_song_lyrics_table',	28),
(112,	'2020_11_20_093408_add_is_locked_to_song_lyrics_table',	28),
(113,	'2021_01_25_214155_add_stats_fields_to_song_lyrics_table',	29),
(114,	'2021_02_09_100513_add_lilypond_key_major_to_song_lyrics_table',	29),
(115,	'2021_03_03_174749_create_failed_jobs_table',	29),
(116,	'2021_03_14_072504_add_indexes',	30),
(117,	'2021_03_12_203723_add_order_to_tags_table',	31),
(118,	'2021_03_14_133112_add_index_to_visits_table',	31),
(119,	'2021_03_14_134123_rename_visitable_to_visitable_type_in_visits_table',	31),
(120,	'2021_03_14_134821_remove_visits_from_song_lyrics_table',	31),
(121,	'2021_03_14_135245_remove_updated_at_from_visits_table',	31),
(122,	'2021_03_14_135654_remove_song_lyric_tag_table',	31),
(123,	'2021_03_14_141718_add_indexes_to_song_lyrics_table',	31),
(124,	'2021_03_14_151754_create_song_lyrics_extension_tables',	31),
(125,	'2021_03_14_153256_move_song_lyrics_data_to_extensions_tables',	31),
(126,	'2021_03_14_154244_delete_old_song_lyric_columns',	31),
(127,	'2021_03_14_202410_delete_null_has_one_relations',	31),
(128,	'2021_03_14_202752_change_has_one_relations_to_non_nullable',	31),
(129,	'2021_03_15_120202_migrate_to_composite_key_in_tabbagles_table',	31),
(130,	'2021_03_15_205534_create_visits_aggregate_table',	31),
(131,	'2021_03_16_213726_change_some_visits_indexes',	31),
(132,	'2021_03_17_121208_compute_visit_stats_for_song_lyrics',	31),
(133,	'2021_03_18_215234_add_song_id_index_to_song_lyrics_table',	31),
(134,	'2021_03_30_195222_create_lilypond_parts_sheet_music_table',	32),
(135,	'2021_04_08_112224_add_is_empty_to_lilypond_parts_sheet_music_table',	32),
(136,	'2021_04_09_174806_create_rendered_scores_table',	33),
(137,	'2021_04_10_185435_rename_global_config_to_score_config_in_lilypond_parts_sheet_music_table',	33),
(138,	'2021_05_10_070159_add_sequence_string_to_lilypond_parts_sheet_music_table',	34),
(139,	'2022_01_09_205648_create_song_lyric_bible_reference',	35),
(140,	'2022_01_10_112014_update_bible_references',	35),
(141,	'2022_01_10_143017_add_lit_cal_identificator_to_tags_table',	35),
(142,	'2022_01_10_153834_update_litrugical_tags',	35),
(143,	'2019_15_12_112000_create_elastic_migrations_table',	36),
(144,	'2023_07_01_161022_add_count_pruned_to_visits_aggregates_table',	36),
(145,	'2023_11_25_221411_add_hymnology_to_song_lyrics_table',	36),
(146,	'2023_11_26_145346_change_hymnology_to_longtext_in_song_lyrics_table',	36),
(147,	'2024_05_15_145346_add_song_name_to_songbook_records_table',	36);

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `news_items`;
CREATE TABLE `news_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fa_icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_type` smallint(6) NOT NULL DEFAULT '0',
  `starts_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `playlists`;
CREATE TABLE `playlists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `public_user_id` int(10) unsigned NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playlists_public_user_id_foreign` (`public_user_id`),
  CONSTRAINT `playlists_public_user_id_foreign` FOREIGN KEY (`public_user_id`) REFERENCES `public_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `playlist_song_lyric`;
CREATE TABLE `playlist_song_lyric` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `playlist_id` int(10) unsigned NOT NULL,
  `song_lyric_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `playlist_song_lyric_playlist_id_foreign` (`playlist_id`),
  KEY `playlist_song_lyric_song_lyric_id_foreign` (`song_lyric_id`),
  CONSTRAINT `playlist_song_lyric_playlist_id_foreign` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `playlist_song_lyric_song_lyric_id_foreign` FOREIGN KEY (`song_lyric_id`) REFERENCES `song_lyrics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `public_users`;
CREATE TABLE `public_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firebase_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_jwt_token` varchar(1500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `public_users_firebase_id_unique` (`firebase_id`),
  KEY `public_users_admin_user_id_foreign` (`admin_user_id`),
  CONSTRAINT `public_users_admin_user_id_foreign` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `rendered_scores`;
CREATE TABLE `rendered_scores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lilypond_parts_sheet_music_id` bigint(20) unsigned DEFAULT NULL,
  `external_id` bigint(20) unsigned DEFAULT NULL,
  `render_config` json DEFAULT NULL,
  `filename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filetype` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secondary_filetypes` json DEFAULT NULL,
  `render_config_hash` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frontend_display_order` smallint(5) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rendered_scores_lilypond_parts_sheet_music_id_index` (`lilypond_parts_sheet_music_id`),
  KEY `rendered_scores_render_config_hash_index` (`render_config_hash`),
  KEY `rendered_scores_external_id_index` (`external_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `revisions`;
CREATE TABLE `revisions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `revisionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '1',
  `group` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `songbooks`;
CREATE TABLE `songbooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shortcut` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `songs_count` int(10) unsigned DEFAULT NULL,
  `updating_at` datetime DEFAULT NULL,
  `updating_user_id` int(10) unsigned DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '1',
  `color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color_text` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `songbook_img_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `songbook_records`;
CREATE TABLE `songbook_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `songbook_id` int(10) unsigned NOT NULL,
  `song_lyric_id` int(10) unsigned DEFAULT NULL,
  `number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placeholder` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `song_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `songbook_records_songbook_id_foreign` (`songbook_id`),
  KEY `songbook_records_song_lyric_id_foreign` (`song_lyric_id`),
  CONSTRAINT `songbook_records_song_lyric_id_foreign` FOREIGN KEY (`song_lyric_id`) REFERENCES `song_lyrics` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `songbook_records_songbook_id_foreign` FOREIGN KEY (`songbook_id`) REFERENCES `songbooks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `songs`;
CREATE TABLE `songs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `song_lyrics`;
CREATE TABLE `song_lyrics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `song_id` int(10) unsigned DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `type` int(10) unsigned DEFAULT '0',
  `has_chords` tinyint(1) NOT NULL DEFAULT '0',
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cs',
  `licence_type` int(11) DEFAULT NULL,
  `licence_content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updating_at` datetime DEFAULT NULL,
  `updating_user_id` int(10) unsigned DEFAULT NULL,
  `has_anonymous_author` tinyint(1) NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `is_approved_by_author` tinyint(1) NOT NULL DEFAULT '0',
  `user_creator_id` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `only_regenschori` tinyint(1) NOT NULL DEFAULT '0',
  `capo` smallint(5) unsigned NOT NULL DEFAULT '0',
  `liturgy_approval_status` smallint(5) unsigned NOT NULL DEFAULT '0',
  `arrangement_of` int(10) unsigned DEFAULT NULL,
  `song_number` int(10) unsigned DEFAULT NULL,
  `bible_refs_src` text COLLATE utf8mb4_unicode_ci,
  `bible_refs_osis` text COLLATE utf8mb4_unicode_ci,
  `secondary_name_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_name_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licence_type_cc` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_sealed` tinyint(1) NOT NULL DEFAULT '0',
  `revision_n_tags` int(10) unsigned NOT NULL DEFAULT '0',
  `revision_n_authors` int(10) unsigned NOT NULL DEFAULT '0',
  `revision_n_songbook_records` int(10) unsigned NOT NULL DEFAULT '0',
  `lilypond_key_major` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hymnology` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `song_lyrics_song_number_unique` (`song_number`),
  KEY `song_lyrics_user_creator_id_foreign` (`user_creator_id`),
  KEY `song_lyrics_arrangement_of_foreign` (`arrangement_of`),
  KEY `song_lyrics_updated_at_index` (`updated_at`),
  KEY `song_lyrics_deleted_at_index` (`deleted_at`),
  KEY `song_lyrics_has_chords_index` (`has_chords`),
  KEY `song_lyrics_song_id_index` (`song_id`),
  CONSTRAINT `song_lyrics_arrangement_of_foreign` FOREIGN KEY (`arrangement_of`) REFERENCES `song_lyrics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `song_lyrics_user_creator_id_foreign` FOREIGN KEY (`user_creator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `song_lyric_bible_reference`;
CREATE TABLE `song_lyric_bible_reference` (
  `song_lyric_id` bigint(20) unsigned NOT NULL,
  `book` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_chapter` smallint(5) unsigned NOT NULL,
  `start_verse` smallint(5) unsigned NOT NULL,
  `end_chapter` smallint(5) unsigned NOT NULL,
  `end_verse` smallint(5) unsigned NOT NULL,
  KEY `song_lyric_bible_reference_book_index` (`book`),
  KEY `song_lyric_bible_reference_start_chapter_start_verse_index` (`start_chapter`,`start_verse`),
  KEY `song_lyric_bible_reference_end_chapter_end_verse_index` (`end_chapter`,`end_verse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `song_lyric_lilypond_src`;
CREATE TABLE `song_lyric_lilypond_src` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `song_lyric_id` bigint(20) unsigned NOT NULL,
  `lilypond_src` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `song_lyric_lilypond_src_song_lyric_id_index` (`song_lyric_id`),
  KEY `song_lyric_lilypond_src_lilypond_src(1)_index` (`lilypond_src`(1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `song_lyric_lilypond_svg`;
CREATE TABLE `song_lyric_lilypond_svg` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `song_lyric_id` bigint(20) unsigned NOT NULL,
  `lilypond_svg` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `song_lyric_lilypond_svg_song_lyric_id_index` (`song_lyric_id`),
  KEY `song_lyric_lilypond_svg_lilypond_svg(1)_index` (`lilypond_svg`(1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `song_lyric_lyrics`;
CREATE TABLE `song_lyric_lyrics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `song_lyric_id` bigint(20) unsigned NOT NULL,
  `lyrics` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `song_lyric_lyrics_song_lyric_id_index` (`song_lyric_id`),
  KEY `song_lyric_lyrics_lyrics(1)_index` (`lyrics`(1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `taggables`;
CREATE TABLE `taggables` (
  `tag_id` int(10) unsigned NOT NULL,
  `taggable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taggable_id` int(10) unsigned NOT NULL,
  KEY `taggables_tag_id_foreign` (`tag_id`),
  KEY `taggables_taggable_id_taggable_type_index` (`taggable_id`,`taggable_type`),
  CONSTRAINT `taggables_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_tag_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `hide_in_liturgy` tinyint(1) NOT NULL DEFAULT '0',
  `order` smallint(5) unsigned DEFAULT NULL,
  `lit_day_identificator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tags_type_index` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `translations`;
CREATE TABLE `translations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) unsigned NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_token` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `stats_json` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_api_token_unique` (`api_token`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `visits`;
CREATE TABLE `visits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `visitable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitable_id` bigint(20) NOT NULL,
  `public_user_id` bigint(20) DEFAULT NULL,
  `source` smallint(6) NOT NULL DEFAULT '0',
  `visit_type` smallint(6) NOT NULL DEFAULT '0',
  `is_mobile` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_created_at_index` (`created_at`),
  KEY `visits_visitable_id_visitable_type_index` (`visitable_id`,`visitable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `visit_aggregates`;
CREATE TABLE `visit_aggregates` (
  `visitable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitable_id` bigint(20) unsigned NOT NULL,
  `count_week` int(10) unsigned NOT NULL,
  `count_after_prune` int(10) unsigned NOT NULL,
  `count_pruned` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`visitable_type`,`visitable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2026-01-31 19:07:14 UTC
